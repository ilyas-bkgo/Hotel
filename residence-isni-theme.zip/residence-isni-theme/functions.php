<?php
/**
 * Residence ISNI Theme Functions & Definitions
 * WordPress 7.1.3 & PHP 8.1+ Compatible
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ISNI_VERSION', '1.0.0');

// 1. Enqueue Scripts, Styles & Fonts
function isni_enqueue_scripts() {
    // Google Fonts
    wp_enqueue_style(
        'isni-google-fonts',
        'https://fonts.googleapis.com/css2?family=Archivo:wght@400;600;700;800;900&family=Bebas+Neue&family=Permanent+Marker&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Sedgwick+Ave+Display&display=swap',
        array(),
        null
    );

    // Main Theme Stylesheet
    wp_enqueue_style('isni-style', get_stylesheet_uri(), array(), ISNI_VERSION);

    // Booking JS
    wp_enqueue_script(
        'isni-booking',
        get_template_directory_uri() . '/assets/booking.js',
        array(),
        ISNI_VERSION,
        true
    );

    // Localize Data for AJAX
    wp_localize_script('isni-booking', 'isniData', array(
        'ajaxUrl'   => admin_url('admin-ajax.php'),
        'nonce'     => wp_create_nonce('isni_booking_nonce'),
        'sheetUrl'  => get_option('isni_sheet_url', ''),
        'whatsapp'  => get_option('isni_whatsapp', '+212 528 820 467'),
        'rooms'     => isni_get_rooms(),
        'breakfast' => isni_get_breakfast()
    ));
}
add_action('wp_enqueue_scripts', 'isni_enqueue_scripts');

function isni_ensure_surf_pages() {
    static $checked = false;
    if ($checked) return;
    $checked = true;
    $rewrite_rules_changed = false;
    $pages = array(
        'debutant' => array('Surf Débutant', 'page-surf-debutant.php'),
        'intermediaire' => array('Surf Intermédiaire', 'page-surf-intermediaire.php')
    );

    foreach ($pages as $level => $settings) {
        $slug = 'surf-' . $level;
        $page = get_page_by_path($slug, OBJECT, 'page');
        if (!$page) {
            $page_id = wp_insert_post(array(
                'post_type' => 'page',
                'post_status' => 'publish',
                'post_title' => $settings[0],
                'post_name' => $slug
            ), true);
            if (is_wp_error($page_id)) continue;
            $page = get_post($page_id);
            $rewrite_rules_changed = true;
        }

        if ($page && get_post_meta($page->ID, '_wp_page_template', true) !== $settings[1]) {
            update_post_meta($page->ID, '_wp_page_template', $settings[1]);
        }
    }

    if ($rewrite_rules_changed) flush_rewrite_rules(false);
}
add_action('after_switch_theme', 'isni_ensure_surf_pages');
function isni_admin_ensure_surf_pages() {
    if (current_user_can('edit_pages')) isni_ensure_surf_pages();
}
add_action('admin_init', 'isni_admin_ensure_surf_pages', 20);

function isni_get_surf_page_url($level) {
    $slug = 'surf-' . sanitize_title($level);
    $page = get_page_by_path($slug, OBJECT, 'page');
    return $page ? get_permalink($page) : home_url('/#activites');
}

// 2. Custom Post Type: isni_booking
function isni_register_cpt_booking() {
    $labels = array(
        'name'               => 'Réservations',
        'singular_name'      => 'Réservation',
        'menu_name'          => 'Réservations ISNI',
        'all_items'          => 'Toutes les réservations',
        'view_item'          => 'Voir réservation',
        'search_items'       => 'Chercher réservation',
        'not_found'          => 'Aucune réservation trouvée'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'menu_icon'          => 'dashicons-calendar-alt',
        'capability_type'    => 'post',
        'hierarchical'       => false,
        'supports'           => array('title', 'custom-fields'),
    );
    register_post_type('isni_booking', $args);
}
add_action('init', 'isni_register_cpt_booking');

// 3. Settings Menu in Admin (Réglages > Résidence)
function isni_add_admin_menu() {
    add_options_page(
        'Paramètres Résidence ISNI',
        'Résidence ISNI',
        'manage_options',
        'isni-settings',
        'isni_render_settings_page'
    );
}
add_action('admin_menu', 'isni_add_admin_menu');

function isni_register_settings() {
    register_setting('isni_settings_group', 'isni_phone');
    register_setting('isni_settings_group', 'isni_email');
    register_setting('isni_settings_group', 'isni_address');
    register_setting('isni_settings_group', 'isni_whatsapp');
    register_setting('isni_settings_group', 'isni_sheet_url');
    register_setting('isni_settings_group', 'isni_rooms_data');
    register_setting('isni_settings_group', 'isni_activities_data');
    register_setting('isni_settings_group', 'isni_breakfast_data');
}
add_action('admin_init', 'isni_register_settings');

function isni_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Configuration Résidence ISNI</h1>
        <form method="post" action="options.php">
            <?php settings_fields('isni_settings_group'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Téléphone</th>
                    <td><input type="text" name="isni_phone" value="<?php echo esc_attr(get_option('isni_phone', '+212 528 820 467')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">WhatsApp</th>
                    <td><input type="text" name="isni_whatsapp" value="<?php echo esc_attr(get_option('isni_whatsapp', '+212 528 820 467')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">Email de réception</th>
                    <td><input type="email" name="isni_email" value="<?php echo esc_attr(get_option('isni_email', 'contact@residence-isni.ma')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">Adresse</th>
                    <td><input type="text" name="isni_address" value="<?php echo esc_attr(get_option('isni_address', 'Avenue Allal Ben Abdellah, Agadir')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">URL Google Apps Script Web App</th>
                    <td>
                        <input type="url" name="isni_sheet_url" value="<?php echo esc_attr(get_option('isni_sheet_url', '')); ?>" class="large-text">
                        <p class="description">URL de la Web App Google Apps Script connectée à votre Google Sheet.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Chambres (code|Nom|capacité|prix MAD/nuit|description)</th>
                    <td>
                        <textarea name="isni_rooms_data" rows="5" class="large-text"><?php echo esc_textarea(get_option('isni_rooms_data', "simple|Chambre simple · 1 personne|1|320|Tarif par nuit selon le barème fourni
double|Chambre double · 2 personnes|2|420|Tarif par nuit selon le barème fourni
triple|Chambre triple · 3 personnes|3|480|Tarif par nuit selon le barème fourni
quadruple|Chambre quadruple · 4 personnes|4|520|Tarif par nuit selon le barème fourni")); ?></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Activités (une ligne par niveau : Nom|Prix|Description)</th>
                    <td>
                        <textarea name="isni_activities_data" rows="3" class="large-text"><?php echo esc_textarea(get_option('isni_activities_data', "Surf · Débutant · Taghazout|Tarif à confirmer|Sortie de surf encadrée avec transport, planche, combinaison et déjeuner annoncés sur l’affiche
Surf · Intermédiaire · Taghazout|Tarif à confirmer|Sortie de surf encadrée avec transport, planche, combinaison et déjeuner annoncés sur l’affiche")); ?></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Petit-déjeuner (code|Nom|prix DH|éléments;séparés)</th>
                    <td>
                        <textarea name="isni_breakfast_data" rows="4" class="large-text"><?php echo esc_textarea(get_option('isni_breakfast_data', "continental|Continental|35|Café ou thé;Jus d'orange;Omelette;Pain, beurre, fromage et charcuterie
express|Express|30|Café ou thé;Jus d'orange;Petit pain au chocolat
beldi|Beldi|35|Café ou thé;1 msemen ou 1 batbout;Jus d'orange;Huile d'olive et fromage")); ?></textarea>
                    </td>
                </tr>
            </table>
            <?php submit_button('Enregistrer les réglages'); ?>
        </form>
    </div>
    <?php
}

// 4. Data Helpers
function isni_get_rooms() {
    $raw = get_option('isni_rooms_data', "simple|Chambre simple · 1 personne|1|320|Tarif par nuit selon le barème fourni
double|Chambre double · 2 personnes|2|420|Tarif par nuit selon le barème fourni
triple|Chambre triple · 3 personnes|3|480|Tarif par nuit selon le barème fourni
quadruple|Chambre quadruple · 4 personnes|4|520|Tarif par nuit selon le barème fourni");
    $lines = explode("
", trim($raw));
    $rooms = array();
    foreach ($lines as $line) {
        $parts = explode('|', trim($line));
        if (count($parts) >= 5) {
            $rooms[$parts[0]] = array(
                'code'        => $parts[0],
                'name'        => $parts[1],
                'capacity'    => intval($parts[2]),
                'price'       => floatval($parts[3]),
                'description' => $parts[4]
            );
        }
    }
    return $rooms;
}

function isni_get_breakfast() {
    $raw = get_option('isni_breakfast_data', "continental|Continental|35|Café ou thé;Jus d'orange;Omelette;Pain, beurre, fromage et charcuterie
express|Express|30|Café ou thé;Jus d'orange;Petit pain au chocolat
beldi|Beldi|35|Café ou thé;1 msemen ou 1 batbout;Jus d'orange;Huile d'olive et fromage");
    $lines = explode("
", trim($raw));
    $bf = array();
    foreach ($lines as $line) {
        $parts = explode('|', trim($line));
        if (count($parts) >= 4) {
            $bf[$parts[0]] = array(
                'code'  => $parts[0],
                'name'  => $parts[1],
                'price' => floatval($parts[2]),
                'items' => explode(';', $parts[3])
            );
        }
    }
    return $bf;
}

// 5. AJAX Availability Endpoint
function isni_ajax_avail() {
    wp_send_json_success(array(
        'room' => sanitize_text_field($_GET['room'] ?? 'double'),
        'fullyBookedDates' => array(),
        'message' => 'La disponibilité est confirmée par la réception après réception de la demande.'
    ));
}
add_action('wp_ajax_isni_avail', 'isni_ajax_avail');
add_action('wp_ajax_nopriv_isni_avail', 'isni_ajax_avail');

// 6. AJAX Booking Submission
function isni_ajax_book() {
    // Nonce check
    if (!check_ajax_referer('isni_booking_nonce', 'nonce', false)) {
        wp_send_json_error(array('message' => 'Session expirée. Veuillez recharger la page.'));
    }

    // Honeypot check
    if (!empty($_POST['website'])) {
        wp_send_json_error(array('message' => 'Anti-spam validation failed.'));
    }

    $name    = sanitize_text_field($_POST['full_name'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $room    = sanitize_text_field($_POST['room_type'] ?? 'double');
    $check_in= sanitize_text_field($_POST['check_in'] ?? '');
    $check_out= sanitize_text_field($_POST['check_out'] ?? '');
    $guests  = max(1, intval($_POST['guests'] ?? 1));
    $bf_code = sanitize_text_field($_POST['breakfast'] ?? 'none');
    $notes   = sanitize_textarea_field($_POST['notes'] ?? '');
    $activities = sanitize_text_field($_POST['activities'] ?? '');

    if (empty($name) || empty($email) || empty($phone) || empty($check_in) || empty($check_out)) {
        wp_send_json_error(array('message' => 'Veuillez remplir tous les champs obligatoires.'));
    }

    $d_in = strtotime($check_in);
    $d_out = strtotime($check_out);
    $today = strtotime(date('Y-m-d'));

    if ($d_in < $today || $d_out <= $d_in) {
        wp_send_json_error(array('message' => 'Dates de séjour invalides.'));
    }

    $nights = max(1, round(($d_out - $d_in) / (60 * 60 * 24)));
    if ($nights > 30) {
        wp_send_json_error(array('message' => 'La durée maximale en ligne est de 30 nuits.'));
    }

    // Calculate total price server-side
    $rooms = isni_get_rooms();
    if (!isset($rooms[$room])) {
        wp_send_json_error(array('message' => 'Veuillez choisir un type de chambre valide.'));
    }
    if ($guests > $rooms[$room]['capacity']) {
        wp_send_json_error(array('message' => 'Le nombre de voyageurs dépasse la capacité de la chambre choisie.'));
    }
    $room_price_night = $rooms[$room]['price'];
    $breakfasts = isni_get_breakfast();
    $bf_price_person = isset($breakfasts[$bf_code]) ? $breakfasts[$bf_code]['price'] : 0;

    $total = ($nights * $room_price_night) + ($nights * $bf_price_person * $guests);

    // Save as CPT isni_booking
    $post_id = wp_insert_post(array(
        'post_type'   => 'isni_booking',
        'post_title'  => "Réservation - " . $name . " (" . $check_in . " au " . $check_out . ")",
        'post_status' => 'publish'
    ));

    if (is_wp_error($post_id)) {
        wp_send_json_error(array('message' => 'Erreur lors de l’enregistrement de votre demande.'));
    }

    update_post_meta($post_id, '_isni_guest_name', $name);
    update_post_meta($post_id, '_isni_email', $email);
    update_post_meta($post_id, '_isni_phone', $phone);
    update_post_meta($post_id, '_isni_room', $room);
    update_post_meta($post_id, '_isni_check_in', $check_in);
    update_post_meta($post_id, '_isni_check_out', $check_out);
    update_post_meta($post_id, '_isni_nights', $nights);
    update_post_meta($post_id, '_isni_guests', $guests);
    update_post_meta($post_id, '_isni_breakfast', $bf_code);
    update_post_meta($post_id, '_isni_total_mad', $total);
    update_post_meta($post_id, '_isni_status', 'en_attente');
    update_post_meta($post_id, '_isni_notes', $notes);
    update_post_meta($post_id, '_isni_activities', $activities);

    // Send email to admin
    $admin_email = get_option('isni_email', 'contact@residence-isni.ma');
    $subject = "Nouvelle demande de réservation Résidence ISNI - " . $name;
    $body = "Nouvelle réservation reçue :\n\n"
          . "Nom : $name\n"
          . "Email : $email\n"
          . "Téléphone : $phone\n"
          . "Chambre : $room\n"
          . "Dates : du $check_in au $check_out ($nights nuits)\n"
          . "Personnes : $guests\n"
          . "Formule Petit-déjeuner : $bf_code\n"
          . "Activités demandées : $activities\n"
          . "Total estimé : $total MAD\n"
          . "Notes : $notes\n\n"
          . "Gérer la réservation : " . admin_url('post.php?post=' . $post_id . '&action=edit');
    wp_mail($admin_email, $subject, $body);

    // Sync to Google Sheet via Google Apps Script Web App URL
    $sheet_url = get_option('isni_sheet_url', '');
    $sheet_sync_warning = empty($sheet_url);
    if (!empty($sheet_url)) {
        $sheet_payload = array(
            'id'            => 'ISNI-' . $post_id,
            'timestamp'     => current_time('mysql'),
            'fullName'      => $name,
            'email'         => $email,
            'phone'         => $phone,
            'roomType'      => $rooms[$room]['name'],
            'roomCode'      => $room,
            'checkIn'       => $check_in,
            'checkOut'      => $check_out,
            'nights'        => $nights,
            'guests'        => $guests,
            'breakfast'     => isset($breakfasts[$bf_code]) ? $breakfasts[$bf_code]['name'] : 'Sans petit-déjeuner',
            'breakfastCode' => $bf_code,
            'roomPriceMAD'  => $nights * $room_price_night,
            'breakfastPriceMAD' => $nights * $bf_price_person * $guests,
            'activities'    => $activities,
            'totalPriceMAD' => $total,
            'status'        => 'en_attente',
            'notes'         => $notes
        );

        $sheet_response = wp_remote_post($sheet_url, array(
            'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
            'body'        => wp_json_encode($sheet_payload),
            'method'      => 'POST',
            'data_format' => 'body',
            'timeout'     => 15,
            'blocking'    => true
        ));
        if (is_wp_error($sheet_response) || wp_remote_retrieve_response_code($sheet_response) >= 400) {
            $sheet_sync_warning = true;
            error_log('ISNI Google Sheets sync failed for booking ISNI-' . $post_id . ': ' . (is_wp_error($sheet_response) ? $sheet_response->get_error_message() : wp_remote_retrieve_response_code($sheet_response)));
        } else {
            $sheet_result = json_decode(wp_remote_retrieve_body($sheet_response), true);
            if (!is_array($sheet_result) || ($sheet_result['status'] ?? '') !== 'success') {
                $sheet_sync_warning = true;
                error_log('ISNI Google Sheets webhook did not confirm booking ISNI-' . $post_id . '.');
            }
        }
    }

    wp_send_json_success(array(
        'bookingId' => 'ISNI-' . $post_id,
        'message'   => 'Votre demande a été enregistrée dans WordPress. La résidence vous contactera pour confirmer la disponibilité.',
        'sheetSyncWarning' => $sheet_sync_warning,
        'totalMAD'  => $total
    ));
}
add_action('wp_ajax_isni_book', 'isni_ajax_book');
add_action('wp_ajax_nopriv_isni_book', 'isni_ajax_book');
