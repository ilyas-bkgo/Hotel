<?php
/**
 * Template Name: Accueil Résidence ISNI
 * Front Page Template
 */

get_header(); ?>

<main id="primary" class="site-main">

    <!-- HERO SECTION -->
    <section class="isni-hero" style="position:relative;background:#f2e8df;padding:48px 24px 80px;overflow:hidden;">
        <div style="position:absolute;top:10px;left:50%;transform:translateX(-50%);white-space:nowrap;z-index:0;" class="ghost-title">
            RÉSIDENCE ISNI
        </div>

        <div style="max-width:1440px;margin:0 auto;position:relative;z-index:2;display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:48px;align-items:center;">
            <div>
                <span style="display:inline-block;background:#06306b;color:#f2e8df;padding:6px 16px;border-radius:9999px;font-size:0.85rem;font-weight:700;text-transform:uppercase;margin-bottom:16px;">
                    Appart-Hôtel & Surf Lifestyle · Agadir
                </span>
                <h1 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(3rem,6vw,5.5rem);line-height:0.95;color:#06306b;margin-bottom:16px;">
                    L'ESPRIT SURF <br>
                    <span style="font-family:'Permanent Marker',cursive;color:#f05a2d;">& HOSPITALITÉ MAROCAINE</span>
                </h1>
                <p style="font-size:1.15rem;color:#06306b;max-width:520px;margin-bottom:28px;">
                    Établissement d’hébergement moderne de 29 chambres, Résidence Isni propose des séjours confortables et fonctionnels aux voyageurs de loisirs comme d’affaires. Située avenue Allal Ben Abdellah, elle offre un équilibre entre confort, intimité et accessibilité, près des restaurants, commerces, cafés, musées et principales attractions d’Agadir.
                </p>
                <div style="display:flex;gap:16px;flex-wrap:wrap;">
                    <a href="#reservation" class="btn-primary">Réserver mon séjour</a>
                    <a href="<?php echo esc_url(home_url('/#chambres')); ?>" style="display:inline-block;padding:14px 28px;border-radius:9999px;border:2px solid #06306b;color:#06306b;font-weight:700;text-transform:uppercase;text-decoration:none;">Voir les chambres</a>
                </div>
            </div>

            <div style="border-radius:24px;overflow:hidden;box-shadow:0 20px 40px rgba(6,48,107,0.12);transform:rotate(1deg);border:4px solid #ffffff;">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/isni/family-suite.jpg'); ?>" alt="Salon et salle à manger d’une suite de la Résidence ISNI" style="width:100%;height:auto;display:block;min-height:380px;object-fit:cover;">
            </div>
        </div>
    </section>

    <!-- TICKER STRIP -->
    <div style="background:#06306b;color:#f2e8df;padding:16px 0;overflow:hidden;white-space:nowrap;font-family:'Bebas Neue',sans-serif;font-size:1.4rem;letter-spacing:0.1em;">
        <div style="display:inline-block;animation:scrollText 25s linear infinite;">
            29 CHAMBRES · TARIFS PAR NUIT · PETIT-DÉJEUNER EN OPTION · SORTIE SURF À TAGHAZOUT SUR DEMANDE ·
        </div>
    </div>

    <!-- SECTION POURQUOI -->
    <section id="pourquoi" style="padding:80px 24px;max-width:1440px;margin:0 auto;">
        <div style="text-align:center;margin-bottom:48px;">
            <span style="font-family:'Permanent Marker',cursive;color:#f05a2d;font-size:1.4rem;">L'Expérience ISNI</span>
            <h2 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(2.5rem,5vw,4rem);color:#06306b;">
                POURQUOI CHOISIR NOTRE RÉSIDENCE ?
            </h2>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;">
            <div class="card-panel" style="padding:32px;background:#ffffff;">
                <div style="font-family:'Bebas Neue',sans-serif;font-size:2.5rem;color:#f05a2d;">01</div>
                <h3 style="font-size:1.25rem;font-weight:700;margin-bottom:8px;">Emplacement Central</h3>
                <p style="color:#4a5568;">Proche des restaurants, commerces, cafés, musées et principales attractions d’Agadir.</p>
            </div>
            <div class="card-panel" style="padding:32px;background:#ffffff;">
                <div style="font-family:'Bebas Neue',sans-serif;font-size:2.5rem;color:#f29acb;">02</div>
                <h3 style="font-size:1.25rem;font-weight:700;margin-bottom:8px;">Wi-Fi et kitchenette</h3>
                <p style="color:#4a5568;">Des équipements signalés dans les informations publiques de l’établissement.</p>
            </div>
            <div class="card-panel" style="padding:32px;background:#ffffff;">
                <div style="font-family:'Bebas Neue',sans-serif;font-size:2.5rem;color:#1f6f78;">03</div>
                <h3 style="font-size:1.25rem;font-weight:700;margin-bottom:8px;">Petit-Déjeuner Beldi & Frais</h3>
                <p style="color:#4a5568;">Formules Continental (35 DH), Express (30 DH) ou Beldi (35 DH), par personne et par jour.</p>
            </div>
            <div class="card-panel" style="padding:32px;background:#ffffff;">
                <div style="font-family:'Bebas Neue',sans-serif;font-size:2.5rem;color:#06306b;">04</div>
                <h3 style="font-size:1.25rem;font-weight:700;margin-bottom:8px;">Sortie surf à Taghazout</h3>
                <p style="color:#4a5568;">Transport vers les spots, planche et combinaison, moniteur et déjeuner annoncés sur l’affiche. Tarif à confirmer.</p>
            </div>
        </div>
    </section>

    <!-- SECTION CHAMBRES (PANNEAUX 50/50) -->
    <section id="chambres" style="padding:60px 24px;background:#faf5f0;">
        <div style="max-width:1440px;margin:0 auto;">
            <div style="text-align:center;margin-bottom:48px;">
                <span style="font-family:'Permanent Marker',cursive;color:#f05a2d;font-size:1.4rem;">Nos Hébergements</span>
                <h2 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(2.5rem,5vw,4rem);color:#06306b;">
                    29 CHAMBRES ET SUITES DE CHARME
                </h2>
            </div>

            <?php
            $rooms = isni_get_rooms();
            $room_images = array(
                'simple'    => get_template_directory_uri() . '/assets/images/isni/twin-bedroom.jpg',
                'double'    => get_template_directory_uri() . '/assets/images/isni/living-room.jpg',
                'triple'    => get_template_directory_uri() . '/assets/images/isni/family-suite.jpg',
                'quadruple' => get_template_directory_uri() . '/assets/images/isni/family-suite.jpg'
            );
            $idx = 0;
            foreach ($rooms as $code => $r):
                $reverse = ($idx % 2 === 1);
            ?>
            <div class="card-panel" style="margin-bottom:40px;display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));overflow:hidden;">
                <div class="isni-image-drift" style="<?php echo $reverse ? 'order:2;' : ''; ?>min-height:340px;background:#e8d9cc;">
                    <img src="<?php echo esc_url($room_images[$code] ?? ''); ?>" alt="<?php echo esc_attr($r['name']); ?>" style="width:100%;height:100%;object-fit:cover;display:block;">
                </div>
                <div style="padding:48px 36px;display:flex;flex-direction:column;justify-content:center;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                        <span style="font-family:'Bebas Neue',sans-serif;font-size:2rem;color:#f05a2d;"><?php echo esc_html($r['price']); ?> MAD <span style="font-size:1rem;font-family:sans-serif;font-weight:normal;">/ nuit</span></span>
                    </div>
                    <h3 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;color:#06306b;margin-bottom:12px;"><?php echo esc_html($r['name']); ?></h3>
                    <p style="color:#4a5568;margin-bottom:24px;line-height:1.6;"><?php echo esc_html($r['description']); ?></p>
                    <div>
                        <a href="#reservation" class="btn-primary" onclick="if(window.isniSelectRoom) window.isniSelectRoom('<?php echo esc_js($code); ?>');">
                            Choisir cette chambre
                        </a>
                    </div>
                </div>
            </div>
            <?php
            $idx++;
            endforeach;
            ?>
            <h3 style="font-family:'Bebas Neue',sans-serif;font-size:2.8rem;color:#06306b;margin:72px 0 8px;text-align:center;">STUDIOS & APPARTEMENTS</h3>
            <p style="max-width:780px;margin:0 auto 32px;text-align:center;color:#4a5568;line-height:1.65;">Les superficies et équipements ci-dessous reprennent les descriptifs transmis. Le tarif dépend du nombre de personnes, selon le barème affiché plus haut.</p>
            <?php
            $accommodation_details = array(
                array('Studio Confort', '36 m²', 'kitchenette.jpg', 'Pensé pour allier confort et fonctionnalité, le studio offre une vue agréable sur le jardin Ibn Zaidoun. Il comprend un grand lit, deux canapés-lits et une kitchenette entièrement équipée. Salle de bain privée avec douche et WC, Wi-Fi gratuit.'),
                array('Studio quadruple · vue jardin', '36 m²', 'twin-bedroom.jpg', 'Configuration adaptée aux familles ou aux amis, avec trois lits simples et deux canapés-lits. Kitchenette équipée, salle de bain privée avec douche et WC, Wi-Fi gratuit et balcon avec vue sur le jardin Ibn Zaidoun.'),
                array('Chambre quadruple avec balcon', '36 m²', 'family-suite.jpg', 'Peut accueillir jusqu’à quatre personnes avec deux lits simples et deux canapés-lits. Kitchenette équipée, salle de bain privée avec douche et WC, balcon et Wi-Fi gratuit. La vue jardin dépend de la disponibilité.'),
                array('Appartement deux chambres', '55 m²', 'twin-bedroom.jpg', 'Hébergement spacieux avec deux chambres séparées, un salon, trois lits simples, un lit double et deux canapés-lits. Kitchenette équipée, salle de bain privée avec douche et WC, Wi-Fi gratuit. Balcon avec vue jardin selon disponibilité.'),
                array('Appartement une chambre', '36 m²', 'living-room.jpg', 'Espace fonctionnel avec deux lits simples et deux canapés-lits, kitchenette équipée, salle de bain privée avec douche et WC et Wi-Fi gratuit. Balcon avec vue sur le jardin Ibn Zaidoun selon disponibilité.')
            );
            ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin:28px 0 60px;">
                <?php foreach ($accommodation_details as $stay): ?>
                <article class="card-panel" style="overflow:hidden;background:#fff;">
                    <div class="isni-image-drift" style="aspect-ratio:16/10;"><img loading="lazy" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/isni/' . $stay[2]); ?>" alt="Espace de la Résidence ISNI · <?php echo esc_attr($stay[0]); ?>" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
                    <div style="padding:22px;"><span style="display:inline-block;border-radius:999px;background:#f2e8df;color:#06306b;padding:4px 11px;font-size:.8rem;font-weight:700;margin-bottom:8px;"><?php echo esc_html($stay[1]); ?></span><h4 style="font-family:'Bebas Neue',sans-serif;font-size:1.65rem;color:#06306b;margin-bottom:8px;"><?php echo esc_html($stay[0]); ?></h4><p style="font-size:.92rem;line-height:1.65;color:#4a5568;"><?php echo esc_html($stay[3]); ?></p></div>
                </article>
                <?php endforeach; ?>
            </div>
            <div style="margin:72px 0 24px;display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;">
                <?php foreach (array('Salon'=>'living-room.jpg','Chambre'=>'twin-bedroom.jpg','Équipements'=>'kitchenette.jpg','Suite'=>'family-suite.jpg','Restauration'=>'dining-room.jpg','Vue'=>'balcony.jpg') as $label=>$image): ?>
                <figure class="card-panel isni-image-drift" style="position:relative;min-height:210px;">
                    <img loading="lazy" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/isni/' . $image); ?>" alt="<?php echo esc_attr($label); ?> de la Résidence ISNI" style="width:100%;height:100%;min-height:210px;object-fit:cover;display:block;">
                    <figcaption style="position:absolute;bottom:0;left:0;right:0;padding:30px 16px 12px;color:white;font-weight:700;background:linear-gradient(transparent,rgba(6,48,107,.75));"><?php echo esc_html($label); ?></figcaption>
                </figure>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- AFFICHE SURF -->
    <section id="activites" style="padding:72px 24px;background:#06306b;color:#f2e8df;">
        <div style="max-width:1120px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:32px;align-items:center;">
            <div class="isni-image-drift" style="border-radius:24px;max-height:560px;min-height:360px;">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/surf_lesson_taghazout_1793212942727.jpg'); ?>" alt="Surfeurs en session sur la côte marocaine" style="width:100%;height:100%;max-height:560px;min-height:360px;object-fit:cover;border-radius:24px;">
            </div>
            <div style="padding:12px 0;">
                <span style="font-family:'Permanent Marker',cursive;color:#f29acb;">RÉSIDENCE ISNI · AGADIR</span>
                <h2 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(3rem,6vw,5rem);line-height:.9;color:#fff;margin:12px 0 20px;">PREMIERS PAS SURF À TAGHAZOUT</h2>
                <p style="font-size:1.05rem;line-height:1.7;color:#f2e8df;">Excursion à Taghazout avec session de surf. L’affiche de la résidence indique le transport vers les spots, la planche et la combinaison, un moniteur et le déjeuner inclus.</p>
                <p style="font-family:'Bebas Neue',sans-serif;font-size:1.6rem;color:#f29acb;">TARIF À CONFIRMER AVEC LA RÉCEPTION</p>
                <p style="font-family:'Bebas Neue',sans-serif;font-size:1.6rem;color:#f29acb;">CHOISISSEZ VOTRE NIVEAU</p>
                <div style="display:flex;flex-wrap:wrap;gap:12px;">
                    <a class="btn-primary" href="<?php echo esc_url(home_url('/surf-debutant/')); ?>">Débutant · Découvrir le parcours</a>
                    <a class="btn-primary" href="<?php echo esc_url(home_url('/surf-intermediaire/')); ?>">Intermédiaire · Voir le parcours</a>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION PETIT-DÉJEUNER -->
    <section id="petit-dejeuner" style="padding:80px 24px;max-width:1440px;margin:0 auto;">
        <div style="text-align:center;margin-bottom:48px;">
            <span style="font-family:'Permanent Marker',cursive;color:#f05a2d;font-size:1.4rem;">Formules Matinales</span>
            <h2 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(2.5rem,5vw,4rem);color:#06306b;">
                LE MENU PETIT-DÉJEUNER
            </h2>
            <p style="color:#4a5568;max-width:600px;margin:0 auto;">
                Préparé chaque matin sur place avec des ingrédients frais. Choisissez votre formule préférée lors de votre réservation !
            </p>
        </div>

        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/breakfast-menu.webp'); ?>" alt="Carte des formules petit-déjeuner" style="display:block;width:min(100%,760px);height:auto;margin:0 auto 32px;border-radius:16px;">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:32px;">
            <?php
            $bf_list = isni_get_breakfast();
            $bf_colors = array('continental' => '#f05a2d', 'express' => '#f05a2d', 'beldi' => '#f05a2d');
            foreach ($bf_list as $code => $b):
            ?>
            <div class="card-panel" style="padding:32px;display:flex;flex-direction:column;justify-content:space-between;border-top:6px solid #1f6f78;">
                <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                        <h3 style="font-family:'Bebas Neue',sans-serif;font-size:2rem;color:#06306b;"><?php echo esc_html($b['name']); ?></h3>
                        <span style="background:#f05a2d;color:#ffffff;font-weight:700;padding:6px 14px;border-radius:9999px;font-size:0.95rem;">
                            <?php echo esc_html($b['price']); ?> DH
                        </span>
                    </div>
                    <ul style="list-style:none;padding:0;margin-bottom:24px;">
                        <?php foreach ($b['items'] as $item): ?>
                        <li style="padding:6px 0;color:#2d3748;display:flex;align-items:center;gap:8px;">
                            <span style="color:#1f6f78;">✔</span> <?php echo esc_html(trim($item)); ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <button type="button" class="btn-primary" style="width:100%;text-align:center;" onclick="if(window.isniSelectBreakfast) window.isniSelectBreakfast('<?php echo esc_js($code); ?>');">
                    Ajouter au séjour
                </button>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- FORMULAIRE DE DEMANDE DE RÉSERVATION -->
    <section id="reservation" style="padding:80px 24px;background:#f2e8df;">
        <div style="max-width:1100px;margin:0 auto;background:#ffffff;border-radius:24px;padding:48px 36px;box-shadow:0 15px 40px rgba(6,48,107,0.1);">
            <div style="text-align:center;margin-bottom:36px;">
                <span style="font-family:'Permanent Marker',cursive;color:#f05a2d;font-size:1.3rem;">Réservation Directe</span>
                <h2 style="font-family:'Bebas Neue',sans-serif;font-size:3rem;color:#06306b;margin-bottom:8px;">
                    COMPOSER VOTRE SÉJOUR
                </h2>
                <p style="color:#4a5568;">Choisissez vos dates, votre hébergement et vos options. Votre demande est enregistrée et transmise à la réception.</p>
            </div>

            <!-- Booking App Container handled by assets/booking.js -->
            <div id="isni-booking-app">
                <!-- JS mounts the date inputs and interactive booking form here -->
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
