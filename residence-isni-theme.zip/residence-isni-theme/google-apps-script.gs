/**
 * Google Apps Script for Résidence ISNI Booking System
 * 
 * Instructions de déploiement :
 * 1. Ouvrez https://script.google.com/ et créez un nouveau projet
 * 2. Nommez le projet "ISNI Réservations Webhook"
 * 3. Remplacez tout le code par ce contenu
 * 4. Cliquez sur Déployer > Nouveau déploiement
 * 5. Sélectionnez le type : "Application Web"
 * 6. Description : "ISNI Booking Receiver"
 * 7. Exécuter en tant que : "Moi" (votre compte Google)
 * 8. Qui a accès : "Tout le monde" (Anyone)
 * 9. Cliquez sur Déployer et copiez l'URL de l'application Web (se termine par /exec)
 * 10. Collez cette URL dans WordPress (Réglages > Résidence) ou dans le panneau de test
 */

function doPost(e) {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) throw new Error("Impossible de verrouiller la feuille. Réessayez.");

  try {
    var rawData = e.postData ? e.postData.contents : "{}";
    var data = JSON.parse(rawData);
    if (data.websiteHoneypot) {
      return ContentService.createTextOutput(JSON.stringify({ status: "ignored" }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    if (!data.fullName || !data.email || !data.phone || !data.checkIn || !data.checkOut) {
      throw new Error("Champs obligatoires manquants.");
    }

    // Ouvrir le classeur actif ou créer l'onglet "Réservations"
    var ss = getIsniSpreadsheet_();

    var sheetName = "Réservations";
    var sheet = ss.getSheetByName(sheetName);

    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      // En-têtes de colonnes
      sheet.appendRow([
        "Horodatage",
        "ID Réservation",
        "Nom Client",
        "Email",
        "Téléphone",
        "Chambre",
        "Date Arrivée",
        "Date Départ",
        "Nuits",
        "Personnes",
        "Formule Petit-Déj",
        "Total (MAD)",
        "Statut",
        "Notes / Demandes",
        "Activités souhaitées"
      ]);

      // Mise en forme des en-têtes
      var headerRange = sheet.getRange("A1:Q1");
      headerRange.setBackground("#06306b");
      headerRange.setFontColor("#ffffff");
      headerRange.setFontWeight("bold");
      sheet.setFrozenRows(1);
    }

    [[15, "Activités souhaitées"], [16, "Prix chambre (MAD)"], [17, "Petit-déjeuner total (MAD)"]].forEach(function(header) {
      if (sheet.getRange(1, header[0]).getValue() !== header[1]) {
        sheet.getRange(1, header[0]).setValue(header[1]).setBackground("#06306b").setFontColor("#ffffff").setFontWeight("bold");
      }
    });

    // Évite les doublons lors d'une nouvelle tentative après un délai réseau.
    var bookingId = data.id || "ISNI-" + new Date().getTime();
    if (sheet.getLastRow() > 1 && sheet.getRange(2, 2, sheet.getLastRow() - 1, 1)
      .createTextFinder(String(bookingId)).matchEntireCell(true).findNext()) {
      return ContentService.createTextOutput(JSON.stringify({ status: "success", id: bookingId, duplicate: true }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // Ajouter la ligne de réservation
    sheet.appendRow([
      safeCell_(data.timestamp || new Date()),
      safeCell_(bookingId),
      safeCell_(data.fullName),
      safeCell_(data.email),
      safeCell_(data.phone),
      safeCell_(data.roomType || ""),
      safeCell_(data.checkIn),
      safeCell_(data.checkOut),
      data.nights || "",
      data.guests || 1,
      safeCell_(data.breakfast || "none"),
      data.totalPriceMAD || 0,
      safeCell_(data.status || "en_attente"),
      safeCell_(data.notes || ""),
      safeCell_(data.activities || ""),
      Number(data.roomPriceMAD) || 0,
      Number(data.breakfastPriceMAD) || 0
    ]);

    // Formatage auto de largeur
    sheet.autoResizeColumns(1, 17);

    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      message: "Réservation enregistrée dans Google Sheets avec succès",
      id: bookingId
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

// À lancer une fois dans l'éditeur Apps Script avant le déploiement.
function initializeIsniSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) ss = SpreadsheetApp.create("Résidence ISNI - Réservations");
  PropertiesService.getScriptProperties().setProperty("ISNI_SPREADSHEET_ID", ss.getId());
  Logger.log("Classeur ISNI prêt : " + ss.getUrl());
  return ss.getUrl();
}

function getIsniSpreadsheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss) return ss;
  var id = PropertiesService.getScriptProperties().getProperty("ISNI_SPREADSHEET_ID");
  if (!id) throw new Error("Lancez initializeIsniSheet() une fois avant le déploiement.");
  return SpreadsheetApp.openById(id);
}

function safeCell_(value) {
  var text = String(value == null ? "" : value);
  return /^[=+@\-\t\r]/.test(text) ? "'" + text : text;
}

function doGet(e) {
  return ContentService.createTextOutput(JSON.stringify({
    status: "online",
    message: "ISNI Google Apps Script Webhook est opérationnel."
  })).setMimeType(ContentService.MimeType.JSON);
}
