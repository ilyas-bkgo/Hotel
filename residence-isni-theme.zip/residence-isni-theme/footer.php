<footer style="background:#06306b;color:#f2e8df;padding:64px 24px 32px;margin-top:64px;">
    <div style="max-width:1440px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:48px;">
        <div>
            <h3 style="font-family:'Bebas Neue',sans-serif;font-size:2.4rem;color:#ffffff;letter-spacing:0.05em;margin-bottom:12px;">
                RÉSIDENCE ISNI
            </h3>
            <p style="color:#cfe5d8;max-width:320px;margin-bottom:20px;font-size:0.95rem;">
                Appart-hôtel à Agadir avec chambres de 1 à 4 personnes, petit-déjeuner en option et sortie surf à Taghazout sur demande.
            </p>
            <p style="color:#f29acb;font-weight:700;"><?php echo esc_html(get_option('isni_address', 'Avenue Allal Ben Abdellah, Agadir')); ?></p>
        </div>

        <div>
            <h4 style="font-family:'Bebas Neue',sans-serif;font-size:1.6rem;color:#f05a2d;letter-spacing:0.05em;margin-bottom:16px;">
                CONTACT & WHATSAPP
            </h4>
            <p style="margin-bottom:8px;">Téléphone : <a href="tel:<?php echo esc_attr(get_option('isni_phone', '+212528820467')); ?>" style="color:#ffffff;text-decoration:none;"><?php echo esc_html(get_option('isni_phone', '+212 528 820 467')); ?></a></p>
            <p style="margin-bottom:8px;">WhatsApp : <a href="https://wa.me/<?php echo esc_attr(preg_replace('/[^0-9]/', '', get_option('isni_whatsapp', '+212528820467'))); ?>" style="color:#ffffff;text-decoration:none;"><?php echo esc_html(get_option('isni_whatsapp', '+212 528 820 467')); ?></a></p>
            <p style="margin-bottom:8px;">E-mail : <a href="mailto:<?php echo esc_attr(get_option('isni_email', 'contact@residence-isni.ma')); ?>" style="color:#ffffff;text-decoration:none;"><?php echo esc_html(get_option('isni_email', 'contact@residence-isni.ma')); ?></a></p>
        </div>

        <div>
            <h4 style="font-family:'Bebas Neue',sans-serif;font-size:1.6rem;color:#f05a2d;letter-spacing:0.05em;margin-bottom:16px;">
                INFOS PRATIQUES
            </h4>
            <p style="color:#cfe5d8;margin-bottom:8px;">• Wi-Fi gratuit</p>
            <p style="color:#cfe5d8;margin-bottom:8px;">• Kitchenette et réfrigérateur dans les logements</p>
            <p style="color:#cfe5d8;margin-bottom:8px;">• Petit-déjeuner en supplément</p>
        </div>
    </div>

    <div style="max-width:1440px;margin:48px auto 0;padding-top:24px;border-top:1px solid rgba(255,255,255,0.1);display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;font-size:0.85rem;color:#cfe5d8;">
        <p>&copy; <?php echo date('Y'); ?> Résidence ISNI · Appart-Hôtel Agadir. Tous droits réservés.</p>
        <p>Inspiré par le lifestyle surf marocain</p>
    </div>
</footer>

<div id="isni-preloader" class="isni-preloader" role="status" aria-live="polite" aria-label="Chargement de la Résidence ISNI">
    <div class="isni-preloader-backdrop" style="background-image:linear-gradient(180deg,rgba(3,31,47,.34),rgba(3,31,47,.62)),url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/surf_lesson_taghazout_1793212942727.jpg'); ?>');"></div>
    <div class="isni-preloader-content">
        <div class="isni-preloader-mark" aria-hidden="true">≈</div>
        <p class="isni-preloader-kicker">Agadir · Maroc</p>
        <h1 class="isni-preloader-title">RÉSIDENCE ISNI</h1>
        <p class="isni-preloader-caption">Préparez-vous à prendre le large</p>
        <div class="isni-preloader-board" aria-hidden="true"></div>
        <div class="isni-preloader-progress" aria-hidden="true"><span></span></div>
        <span class="screen-reader-text">Chargement en cours…</span>
    </div>
    <svg class="isni-preloader-waves" viewBox="0 0 1440 320" preserveAspectRatio="none" aria-hidden="true">
        <path class="isni-wave-back" fill="rgba(31,111,120,.78)" d="M0,160 C180,220 260,90 450,145 C640,205 750,275 960,180 C1150,95 1270,125 1440,170 L1440,320 L0,320 Z" />
        <path class="isni-wave-front" fill="#f2e8df" d="M0,210 C170,140 310,235 490,195 C700,145 820,120 1010,205 C1180,280 1290,225 1440,185 L1440,320 L0,320 Z" />
    </svg>
</div>
<script>(function(){var el=document.getElementById('isni-preloader');if(!el)return;var done=false;function hide(){if(done)return;done=true;var wait=Math.max(0,1500-(performance.now()-started));window.setTimeout(function(){el.classList.add('is-leaving');window.setTimeout(function(){if(el.parentNode)el.remove();},380);},wait);}var started=performance.now();if(document.readyState==='complete')hide();else window.addEventListener('load',hide,{once:true});window.setTimeout(hide,2200);}());</script>

<?php wp_footer(); ?>
</body>
</html>
