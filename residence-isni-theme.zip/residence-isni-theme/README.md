# Thème WordPress Résidence ISNI & Synchronisation Google Sheets

Thème WordPress sur mesure développé pour l'Appart-Hôtel Résidence ISNI à Agadir (29 chambres).
Avenue Allal Ben Abdellah, Agadir, Maroc.

## Contenu de l'archive
- `style.css` : Déclaration du thème Résidence ISNI et styles personnalisés (fond crème #f2e8df, orange #f05a2d, bleu marine #06306b).
- `functions.php` : Configuration WordPress 7.1.3 + PHP 8.1, menu Réglages > Résidence, CPT `isni_booking`, requêtes AJAX sécurisées (nonce + honeypot anti-spam), calcul de prix côté serveur.
- `header.php` & `footer.php` : Coquille WordPress qui monte la même application React que le site local.
- `assets/theme-app/isni-app.js` et `isni-app.css` : application compilée partagée, pour conserver le même contenu, les mêmes styles et interactions.
- `front-page.php` : Monte l’application React sur l’accueil.
- `page-surf-debutant.php` et `page-surf-intermediaire.php` : pages dédiées créées automatiquement à l’activation.
- `index.php` : Template de secours.
- `google-apps-script.gs` : Script Google Apps Script pour synchroniser automatiquement chaque réservation dans votre Google Sheet en temps réel.

## Installation sur WordPress (cPanel / WP Toolkit)
1. Dans votre panneau d'administration WordPress, allez dans **Apparence > Thèmes > Ajouter un thème > Téléverser un thème**.
2. Sélectionnez le fichier `residence-isni-theme.zip` et cliquez sur **Installer maintenant**.
3. Cliquez sur **Activer**.
4. Les pages **Surf Débutant** et **Surf Intermédiaire** sont créées à l’activation du thème.
5. Dans **Réglages > Résidence**, vérifiez les coordonnées préremplies et ajoutez l’URL de votre Google Sheet.
6. Créez une page nommée "Accueil" et dans **Réglages > Lecture**, choisissez "Une page statique" et sélectionnez "Accueil".

## Déploiement de Google Sheets
1. Rendez-vous sur https://script.google.com/
2. Créez un nouveau projet et collez le contenu de `google-apps-script.gs`.
3. Sélectionnez `initializeIsniSheet`, cliquez sur **Exécuter** et autorisez l'accès à Google Sheets. Copiez l'URL indiquée dans le journal d'exécution. Cette étape mémorise le classeur unique utilisé par les réservations.
4. Cliquez sur Déployer > Nouveau déploiement > Application Web, choisissez **Exécuter en tant que : Moi** et définissez l'accès sur **Tout le monde**.
5. Copiez l'URL qui se termine par `/exec` et collez-la dans Réglages > Résidence dans votre admin WordPress.
6. Le thème attend la réponse de Google Apps Script et affiche un avertissement si l’écriture n’est pas confirmée. Les demandes restent aussi enregistrées dans WordPress ; vérifiez une ligne réelle dans l’onglet Réservations après un essai.
