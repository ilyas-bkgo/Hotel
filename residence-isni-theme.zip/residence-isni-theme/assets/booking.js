/**
 * Residence ISNI - Interactive Booking Calendar & Google Sheets Bridge
 * Vanilla JavaScript (Zero external dependencies)
 */

document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('isni-booking-app');
    if (!container) return;

    const data = window.isniData || {
        ajaxUrl: '/wp-admin/admin-ajax.php',
        nonce: '',
        rooms: {
            simple: { name: 'Chambre simple · 1 personne', price: 320, capacity: 1 },
            double: { name: 'Chambre double · 2 personnes', price: 420, capacity: 2 },
            triple: { name: 'Chambre triple · 3 personnes', price: 480, capacity: 3 },
            quadruple: { name: 'Chambre quadruple · 4 personnes', price: 520, capacity: 4 }
        },
        breakfast: {
            none: { name: 'Sans petit-déjeuner', price: 0 },
            continental: { name: 'Continental', price: 35 },
            express: { name: 'Express', price: 30 },
            beldi: { name: 'Beldi (Traditionnel)', price: 35 }
        }
    };

    let selectedRoom = 'double';
    let checkInDate = '';
    let checkOutDate = '';
    let guests = 2;
    let selectedBreakfast = 'none';
    const activityLabels = {
        'surf-debutant': 'Surf · Débutant · Taghazout',
        'surf-intermediaire': 'Surf · Intermédiaire · Taghazout'
    };
    let selectedActivities = [];
    const requestedActivity = new URLSearchParams(window.location.search).get('isni_activity');
    if (activityLabels[requestedActivity]) selectedActivities = [requestedActivity];
    let guestName = '';
    let guestEmail = '';
    let guestPhone = '';
    let guestNotes = '';

    function localISODate(date) {
        return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0')].join('-');
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    }

    function updateActivityUI() {
        Object.keys(activityLabels).forEach(function(code) {
            const checkbox = document.getElementById('isni-activity-' + code);
            if (checkbox) checkbox.checked = selectedActivities.includes(code);
        });
        const summary = document.getElementById('isni-activity-summary');
        if (summary) summary.textContent = selectedActivities.length
            ? selectedActivities.map(code => activityLabels[code] + ' · Tarif à confirmer').join(' ; ')
            : 'Aucune activité sélectionnée';
        updateWhatsAppLink();
    }

    function updateWhatsAppLink() {
        const link = document.getElementById('isni-whatsapp-link');
        if (!link) return;
        const dates = checkInDate && checkOutDate ? checkInDate + ' au ' + checkOutDate + ' (' + nightsBetween() + ' nuits)' : 'à préciser';
        const room = data.rooms[selectedRoom] || {};
        const breakfast = data.breakfast[selectedBreakfast] || { name: 'Sans petit-déjeuner', price: 0 };
        const nights = nightsBetween();
        const roomTotal = nights * (Number(room.price) || 0);
        const breakfastTotal = nights * (Number(breakfast.price) || 0) * guests;
        const total = roomTotal + breakfastTotal;
        const activityText = selectedActivities.length ? selectedActivities.map(code => activityLabels[code]).join(', ') + ' (tarif à confirmer)' : 'Aucune';
        const message = [
            'Bonjour Résidence ISNI Agadir ! Je souhaite envoyer cette demande de réservation :',
            'Hébergement : ' + (room.name || selectedRoom),
            'Dates : ' + dates,
            'Voyageurs : ' + guests,
            'Petit-déjeuner : ' + breakfast.name + ' (' + (Number(breakfast.price) || 0) + ' DH/personne/jour)',
            'Prix chambre : ' + roomTotal + ' MAD',
            'Prix petits-déjeuners : ' + breakfastTotal + ' MAD',
            'Activités : ' + activityText,
            'Total estimé hors activités : ' + total + ' MAD',
            'Nom : ' + (guestName || 'à compléter'),
            'Email : ' + (guestEmail || 'à compléter'),
            'Téléphone / WhatsApp : ' + (guestPhone || 'à compléter'),
            'Demandes particulières : ' + (guestNotes || 'aucune'),
            'Merci de me confirmer la disponibilité.'
        ].join('\n');
        const phone = String(data.whatsapp || '+212 528 820 467').replace(/[^0-9]/g, '');
        link.href = 'https://wa.me/' + phone + '?text=' + encodeURIComponent(message);
    }

    function nightsBetween() {
        if (!checkInDate || !checkOutDate) return 0;
        const diff = Date.parse(checkOutDate + 'T00:00:00Z') - Date.parse(checkInDate + 'T00:00:00Z');
        return diff > 0 ? Math.round(diff / 86400000) : 0;
    }

    function calculateTotal() {
        if (!checkInDate || !checkOutDate) return 0;
        const d1 = Date.parse(checkInDate + 'T00:00:00Z');
        const d2 = Date.parse(checkOutDate + 'T00:00:00Z');
        const diffTime = d2 - d1;
        if (diffTime <= 0) return 0;
        const nights = Math.round(diffTime / 86400000);
        const rPrice = (data.rooms[selectedRoom] ? data.rooms[selectedRoom].price : 420);
        const bfPrice = (data.breakfast[selectedBreakfast] ? data.breakfast[selectedBreakfast].price : 0);
        return (nights * rPrice) + (nights * bfPrice * guests);
    }

    function render() {
        const existingName = document.getElementById('isni-name');
        if (existingName) guestName = existingName.value;
        const existingEmail = document.getElementById('isni-email');
        if (existingEmail) guestEmail = existingEmail.value;
        const existingPhone = document.getElementById('isni-phone');
        if (existingPhone) guestPhone = existingPhone.value;
        const existingNotes = document.getElementById('isni-notes');
        if (existingNotes) guestNotes = existingNotes.value;
        const total = calculateTotal();
        const dateDiff = (checkInDate && checkOutDate) ? Date.parse(checkOutDate + 'T00:00:00Z') - Date.parse(checkInDate + 'T00:00:00Z') : 0;
        const nights = dateDiff > 0 ? Math.round(dateDiff / 86400000) : 0;

        container.innerHTML = `
            <form id="isni-booking-form" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;">
                <input type="text" name="website" style="display:none;" tabindex="-1" autocomplete="off">

                <div style="background:#f2e8df;padding:24px;border-radius:16px;">
                    <h4 style="font-family:'Bebas Neue',sans-serif;font-size:1.5rem;color:#06306b;margin-bottom:16px;">1. Dates & Chambre</h4>
                    
                    <div style="margin-bottom:16px;">
                        <label style="display:block;font-weight:600;font-size:0.85rem;margin-bottom:6px;">Type de Chambre</label>
                        <select id="isni-room-select" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:1rem;background:#fff;">
                            ${Object.keys(data.rooms).map(code => `
                                <option value="${code}" ${code === selectedRoom ? 'selected' : ''}>${data.rooms[code].name} (${data.rooms[code].price} MAD / nuit)</option>
                            `).join('')}
                        </select>
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
                        <div>
                            <label style="display:block;font-weight:600;font-size:0.85rem;margin-bottom:6px;">Arrivée</label>
                            <input type="date" id="isni-checkin" value="${checkInDate}" min="${localISODate(new Date())}" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:0.95rem;background:#fff;" required>
                        </div>
                        <div>
                            <label style="display:block;font-weight:600;font-size:0.85rem;margin-bottom:6px;">Départ</label>
                            <input type="date" id="isni-checkout" value="${checkOutDate}" min="${checkInDate || localISODate(new Date())}" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:0.95rem;background:#fff;" required>
                        </div>
                    </div>

                    <div style="margin-bottom:16px;">
                        <label style="display:block;font-weight:600;font-size:0.85rem;margin-bottom:6px;">Nombre de Personnes</label>
                        <select id="isni-guests-select" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:1rem;background:#fff;">
                            ${[1, 2, 3, 4].map(count => '<option value="' + count + '" ' + (guests === count ? 'selected' : '') + '>' + count + ' ' + (count === 1 ? 'Personne' : 'Personnes') + '</option>').join('')}
                        </select>
                    </div>

                    <div>
                        <label style="display:block;font-weight:600;font-size:0.85rem;margin-bottom:6px;">Formule Petit-Déjeuner</label>
                        <select id="isni-bf-select" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:1rem;background:#fff;">
                            <option value="none" ${selectedBreakfast === 'none' ? 'selected' : ''}>Sans petit-déjeuner</option>
                            <option value="beldi" ${selectedBreakfast === 'beldi' ? 'selected' : ''}>Beldi traditionnel (+35 DH / pers / jour)</option>
                            <option value="continental" ${selectedBreakfast === 'continental' ? 'selected' : ''}>Continental (+35 DH / pers / jour)</option>
                            <option value="express" ${selectedBreakfast === 'express' ? 'selected' : ''}>Express (+30 DH / pers / jour)</option>
                        </select>
                    </div>
                </div>

                <div style="background:#f2e8df;padding:24px;border-radius:16px;display:flex;flex-direction:column;justify-content:space-between;">
                    <div>
                        <h4 style="font-family:'Bebas Neue',sans-serif;font-size:1.5rem;color:#06306b;margin-bottom:16px;">2. Vos Coordonnées</h4>
                        
                        <div style="margin-bottom:12px;">
                            <input type="text" id="isni-name" value="${escapeHtml(guestName)}" placeholder="Nom et Prénom *" required style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:0.95rem;background:#fff;">
                        </div>
                        <div style="margin-bottom:12px;">
                            <input type="email" id="isni-email" value="${escapeHtml(guestEmail)}" placeholder="Adresse Email *" required style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:0.95rem;background:#fff;">
                        </div>
                        <div style="margin-bottom:12px;">
                            <input type="tel" id="isni-phone" value="${escapeHtml(guestPhone)}" placeholder="Téléphone / WhatsApp *" required style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:0.95rem;background:#fff;">
                        </div>
                        <div style="margin-bottom:12px;">
                            <textarea id="isni-notes" rows="2" placeholder="Demandes particulières (cours de surf, heure d'arrivée...)" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;font-size:0.95rem;background:#fff;">${escapeHtml(guestNotes)}</textarea>
                        </div>
                        <div style="margin:12px 0;padding:12px;background:#fff;border:1px solid #d8deea;border-radius:10px;">
                            <strong style="display:block;margin-bottom:8px;color:#06306b;">Activités surf sélectionnées</strong>
                            <label style="display:flex;gap:8px;align-items:flex-start;color:#06306b;font-size:.9rem;margin:8px 0;">
                                <input type="checkbox" id="isni-activity-surf-debutant" ${selectedActivities.includes('surf-debutant') ? 'checked' : ''}>
                                <span>Surf · Débutant · Taghazout — tarif à confirmer</span>
                            </label>
                            <label style="display:flex;gap:8px;align-items:flex-start;color:#06306b;font-size:.9rem;margin:8px 0;">
                                <input type="checkbox" id="isni-activity-surf-intermediaire" ${selectedActivities.includes('surf-intermediaire') ? 'checked' : ''}>
                                <span>Surf · Intermédiaire · Taghazout — tarif à confirmer</span>
                            </label>
                        </div>
                    </div>

                    <div style="border-top:2px dashed #06306b;padding-top:16px;margin-top:16px;">
                        <div style="margin-bottom:10px;color:#06306b;font-size:.85rem;"><strong>Activités choisies :</strong> <span id="isni-activity-summary"></span></div>
                        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                            <span style="font-weight:600;color:#06306b;">Total estimé (${nights} nuits, hors activités à confirmer) :</span>
                            <span style="font-family:'Bebas Neue',sans-serif;font-size:2rem;color:#f05a2d;">${total} MAD</span>
                        </div>
                        <button type="submit" id="isni-submit-btn" style="width:100%;background:#f05a2d;color:#fff;border:none;padding:14px;border-radius:9999px;font-weight:700;font-size:1rem;text-transform:uppercase;cursor:pointer;">
                            Envoyer ma demande de réservation
                        </button>
                        <a id="isni-whatsapp-link" href="#" target="_blank" rel="noopener noreferrer" style="display:block;margin-top:14px;text-align:center;color:#128c4a;font-size:.9rem;font-weight:700;">Ou envoyer le récapitulatif complet par WhatsApp</a>
                    </div>
                </div>
            </form>
            <div id="isni-feedback" style="margin-top:20px;display:none;padding:16px;border-radius:8px;"></div>
        `;

        // Restore guest details after the form redraws and keep the selected activity visible.
        document.getElementById('isni-name').value = guestName;
        document.getElementById('isni-email').value = guestEmail;
        document.getElementById('isni-phone').value = guestPhone;
        updateActivityUI();
        ['isni-name', 'isni-email', 'isni-phone', 'isni-notes'].forEach(function(id) {
            document.getElementById(id).addEventListener('input', function(e) {
                if (id === 'isni-name') guestName = e.target.value;
                if (id === 'isni-email') guestEmail = e.target.value;
                if (id === 'isni-phone') guestPhone = e.target.value;
                if (id === 'isni-notes') guestNotes = e.target.value;
                updateWhatsAppLink();
            });
        });
        ['surf-debutant', 'surf-intermediaire'].forEach(function(code) {
            document.getElementById('isni-activity-' + code).addEventListener('change', function(e) {
                selectedActivities = e.target.checked
                    ? Array.from(new Set([...selectedActivities, code]))
                    : selectedActivities.filter(activity => activity !== code);
                updateActivityUI();
            });
        });

        // Wire event handlers
        document.getElementById('isni-room-select').addEventListener('change', function(e) {
            selectedRoom = e.target.value;
            guests = data.rooms[selectedRoom].capacity;
            render();
        });
        document.getElementById('isni-checkin').addEventListener('change', function(e) {
            checkInDate = e.target.value;
            render();
        });
        document.getElementById('isni-checkout').addEventListener('change', function(e) {
            checkOutDate = e.target.value;
            render();
        });
        document.getElementById('isni-guests-select').addEventListener('change', function(e) {
            guests = parseInt(e.target.value);
            const matchingRoom = Object.keys(data.rooms).find(code => data.rooms[code].capacity === guests);
            if (matchingRoom) selectedRoom = matchingRoom;
            render();
        });
        document.getElementById('isni-bf-select').addEventListener('change', function(e) {
            selectedBreakfast = e.target.value;
            render();
        });

        document.getElementById('isni-booking-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const submitBtn = document.getElementById('isni-submit-btn');
            const feedback = document.getElementById('isni-feedback');
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Envoi en cours...';

            const formData = new FormData();
            formData.append('action', 'isni_book');
            formData.append('nonce', data.nonce);
            formData.append('full_name', document.getElementById('isni-name').value);
            formData.append('email', document.getElementById('isni-email').value);
            formData.append('phone', document.getElementById('isni-phone').value);
            formData.append('room_type', selectedRoom);
            formData.append('check_in', checkInDate);
            formData.append('check_out', checkOutDate);
            formData.append('guests', guests);
            formData.append('breakfast', selectedBreakfast);
            formData.append('notes', document.getElementById('isni-notes').value);
            formData.append('activities', selectedActivities.map(code => activityLabels[code]).join(', '));
            formData.append('website', document.querySelector('input[name="website"]').value);

            fetch(data.ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(response => {
                feedback.style.display = 'block';
                if (response.success) {
                    feedback.style.background = '#d4edda';
                    feedback.style.color = '#155724';
                    feedback.innerHTML = '<strong>Demande enregistrée.</strong> ' + response.data.message + (response.data.sheetSyncWarning ? '<br><strong>Google Sheets :</strong> synchronisation non confirmée. Contactez la résidence pour vérifier votre demande.' : '');
                } else {
                    feedback.style.background = '#f8d7da';
                    feedback.style.color = '#721c24';
                    feedback.innerHTML = '<strong>Erreur :</strong> ' + (response.data ? response.data.message : 'Une erreur est survenue.');
                }
                submitBtn.disabled = false;
                submitBtn.textContent = 'Envoyer ma demande de réservation';
            })
            .catch(err => {
                feedback.style.display = 'block';
                feedback.style.background = '#f8d7da';
                feedback.style.color = '#721c24';
                feedback.innerHTML = 'Erreur réseau. Veuillez réessayer ou nous contacter par WhatsApp.';
                submitBtn.disabled = false;
                submitBtn.textContent = 'Envoyer ma demande de réservation';
            });
        });
    }

    // Expose helpers for outside buttons
    window.isniSelectRoom = function(code) {
        selectedRoom = code;
        guests = data.rooms[code] ? data.rooms[code].capacity : guests;
        render();
        const el = document.getElementById('reservation');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
    };

    window.isniSelectBreakfast = function(code) {
        selectedBreakfast = code;
        render();
        const el = document.getElementById('reservation');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
    };

    window.isniSelectActivity = function(code) {
        if (!activityLabels[code]) return;
        selectedActivities = selectedActivities.includes(code)
            ? selectedActivities.filter(activity => activity !== code)
            : [...selectedActivities, code];
        updateActivityUI();
        const el = document.getElementById('reservation');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
    };

    render();
});
