<?php
/**
 * Template Name: Surf Intermédiaire
 * Template Post Type: page
 */
get_header(); ?><div id="root"></div><?php get_footer(); ?>