<!DOCTYPE html>
<html <?php language_attributes(); ?>><head>
<meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Résidence ISNI, appart-hôtel à Agadir. Chambres, petit-déjeuner et activités surf.">
<?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?>