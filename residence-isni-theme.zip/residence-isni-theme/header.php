<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="isni-top-bar" style="background:#f2e8df;border-bottom:1px solid rgba(6,48,107,0.1);position:sticky;top:0;z-index:99;padding:16px 24px;">
    <div style="max-width:1440px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:32px;">
        <a href="<?php echo esc_url(home_url('/')); ?>" style="font-family:'Bebas Neue',sans-serif;font-size:2rem;color:#06306b;text-decoration:none;letter-spacing:0.05em;white-space:nowrap;">
            RÉSIDENCE ISNI <span style="font-family:'Permanent Marker',cursive;color:#f05a2d;font-size:1.3rem;">AGADIR</span>
        </a>

        <nav class="isni-nav" style="display:flex;align-items:center;gap:24px;">
            <a href="<?php echo esc_url(home_url('/#pourquoi')); ?>" style="color:#06306b;text-decoration:none;font-weight:600;font-size:0.95rem;">Pourquoi</a>
            <a href="<?php echo esc_url(home_url('/#chambres')); ?>" style="color:#06306b;text-decoration:none;font-weight:600;font-size:0.95rem;">Chambres</a>
            <div class="isni-surf-menu" style="position:relative;display:inline-flex;align-items:center;gap:6px;color:#06306b;font-weight:600;font-size:.95rem;cursor:pointer;">
                <span tabindex="0">Surf⌄</span>
                <div style="display:none;position:absolute;top:100%;left:0;min-width:180px;padding:8px;background:#fff;border-radius:12px;box-shadow:0 12px 28px rgba(6,48,107,.18);">
                    <a href="<?php echo esc_url(home_url('/surf-debutant/')); ?>" style="display:block;padding:10px 12px;color:#06306b;text-decoration:none;">Débutant</a>
                    <a href="<?php echo esc_url(home_url('/surf-intermediaire/')); ?>" style="display:block;padding:10px 12px;color:#06306b;text-decoration:none;">Intermédiaire</a>
                </div>
            </div>
            <a href="<?php echo esc_url(home_url('/#petit-dejeuner')); ?>" style="color:#06306b;text-decoration:none;font-weight:600;font-size:0.95rem;">Petit-Déjeuner</a>
            <a href="<?php echo esc_url(home_url('/#a-savoir')); ?>" style="color:#06306b;text-decoration:none;font-weight:600;font-size:0.95rem;">À Savoir</a>
        </nav>

    </div>
</header>
<script>
document.addEventListener('DOMContentLoaded', function(){ const menu=document.querySelector('.isni-surf-menu'); if(!menu)return; const panel=menu.querySelector('div'); const trigger=menu.querySelector('span'); trigger.addEventListener('click',function(){panel.style.display=panel.style.display==='block'?'none':'block';}); menu.addEventListener('mouseenter',function(){panel.style.display='block';}); menu.addEventListener('mouseleave',function(){panel.style.display='none';}); });
</script>
