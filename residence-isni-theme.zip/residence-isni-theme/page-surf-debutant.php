<?php
/**
 * Template Name: Surf Débutant
 * Template Post Type: page
 */
get_header(); ?>
<main style="background:#faf5f0;color:#06306b;">
<section style="position:relative;overflow:hidden;background:#06306b;color:white;min-height:530px;display:flex;align-items:center;">
<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/surf_lesson_taghazout_1793212942727.jpg'); ?>" alt="Session de surf à Taghazout" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.38;">
<div style="position:absolute;inset:0;background:linear-gradient(90deg,rgba(6,48,107,.96),rgba(6,48,107,.64),rgba(6,48,107,.15));"></div>
<div style="position:relative;z-index:1;max-width:1200px;width:100%;margin:0 auto;padding:72px 24px;">
<a href="<?php echo esc_url(home_url('/#activites')); ?>" style="color:#fff;text-decoration:none;font-weight:700;">← Retour aux activités</a>
<p style="font-family:'Permanent Marker',cursive;color:#f29acb;margin:42px 0 12px;text-transform:uppercase;letter-spacing:.14em;">Surf · Taghazout · Débutant</p>
<h1 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(4rem,9vw,8rem);line-height:.88;margin:0;max-width:850px;">DÉCOUVRIR LE SURF</h1>
<p style="max-width:670px;font-size:1.2rem;line-height:1.7;color:rgba(255,255,255,.88);">Vous n’avez jamais surfé ou souhaitez reprendre les bases ? Une sortie encadrée à Taghazout pour découvrir le surf à votre rythme.</p>
<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:28px;"><span style="border:1px solid rgba(255,255,255,.4);border-radius:999px;padding:9px 15px;">Transport vers les spots</span><span style="border:1px solid rgba(255,255,255,.4);border-radius:999px;padding:9px 15px;">Planche & combinaison</span><span style="border:1px solid rgba(255,255,255,.4);border-radius:999px;padding:9px 15px;">Moniteur & déjeuner</span></div>
</div></section>
<section style="max-width:1200px;margin:0 auto;padding:72px 24px;">
<p style="font-family:'Permanent Marker',cursive;color:#f05a2d;">VOTRE PARCOURS</p><h2 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(2.8rem,5vw,4.5rem);margin:0 0 28px;">APPRENDRE À SON RYTHME</h2>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:18px;">
<article class="card-panel" style="padding:24px;transition:transform .25s,box-shadow .25s;"><span style="font-family:'Bebas Neue',sans-serif;color:#f05a2d;font-size:2.7rem;">01</span><h3 style="font-size:1.2rem;margin:8px 0;">Prendre ses repères</h3><p style="color:#4a5568;line-height:1.65;">Découvrir la planche, les consignes de sécurité et le briefing avant la session.</p></article><article class="card-panel" style="padding:24px;transition:transform .25s,box-shadow .25s;"><span style="font-family:'Bebas Neue',sans-serif;color:#f05a2d;font-size:2.7rem;">02</span><h3 style="font-size:1.2rem;margin:8px 0;">Apprendre les bases</h3><p style="color:#4a5568;line-height:1.65;">Travailler la position sur la planche, la rame et le redressement avec le moniteur.</p></article><article class="card-panel" style="padding:24px;transition:transform .25s,box-shadow .25s;"><span style="font-family:'Bebas Neue',sans-serif;color:#f05a2d;font-size:2.7rem;">03</span><h3 style="font-size:1.2rem;margin:8px 0;">Se lancer dans les vagues</h3><p style="color:#4a5568;line-height:1.65;">Découvrir les premières vagues adaptées au niveau et aux conditions du jour.</p></article>
</div>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:28px;margin-top:34px;">
<div style="background:#f2e8df;border-radius:24px;padding:30px;"><h3 style="font-family:'Bebas Neue',sans-serif;font-size:2rem;">POINTS À ABORDER</h3><ul style="line-height:2;"><li>Sécurité et repères dans l’eau</li><li>Équilibre et position sur la planche</li><li>Rame et redressement</li><li>Découverte des premières vagues</li></ul></div>
<div style="background:#fff;border-radius:24px;padding:30px;box-shadow:0 10px 30px rgba(6,48,107,.08);"><h3 style="font-family:'Bebas Neue',sans-serif;font-size:2rem;">SORTIE SUR DEMANDE</h3><p style="line-height:1.7;color:#4a5568;">L’affiche ISNI annonce le transport vers les spots, la planche, la combinaison, un moniteur et le déjeuner. Le tarif, les horaires, le déroulement et la disponibilité sont à confirmer par la résidence.</p><a class="btn-primary" href="<?php echo esc_url(add_query_arg('isni_activity', 'surf-debutant', home_url('/'))); ?>#reservation">Ajouter à ma demande · Tarif à confirmer</a><p style="font-size:.82rem;color:#718096;margin-top:12px;">Le montant surf n’est pas inclus dans l’estimation en ligne.</p></div>
</div></section>
<section style="background:#fff;padding:72px 24px;"><div style="max-width:1200px;margin:0 auto;"><p style="font-family:'Permanent Marker',cursive;color:#f05a2d;">QUESTIONS FRÉQUENTES</p><h2 style="font-family:'Bebas Neue',sans-serif;font-size:clamp(2.8rem,5vw,4.5rem);">AVANT DE PARTIR SURFER</h2><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px;">
<div class="card-panel" style="padding:24px;"><h3>Le matériel est-il inclus ?</h3><p style="color:#4a5568;line-height:1.6;">L’affiche indique planche et combinaison incluses. Les détails sont à confirmer avec la réception.</p></div>
<div class="card-panel" style="padding:24px;"><h3>Quel est le tarif ?</h3><p style="color:#4a5568;line-height:1.6;">Aucun tarif par niveau n’a été fourni. La réception confirmera le prix et la disponibilité.</p></div>
<div class="card-panel" style="padding:24px;"><h3>Le parcours est-il fixe ?</h3><p style="color:#4a5568;line-height:1.6;">Les points présentés sont des objectifs possibles, pas un programme garanti. Le contenu est à confirmer avec la résidence et le moniteur.</p></div>
</div><p style="margin-top:28px;"><a href="<?php echo esc_url(isni_get_surf_page_url('intermediaire')); ?>" style="color:#1f6f78;font-weight:700;">Découvrir le niveau intermédiaire →</a></p></div></section>
</main>
<?php get_footer(); ?>