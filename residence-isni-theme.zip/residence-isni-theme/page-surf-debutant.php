<?php
/**
 * Template Name: Surf Débutant
 * Template Post Type: page
 */
get_header(); ?><div id="root"></div><?php get_footer(); ?>